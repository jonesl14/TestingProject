[IMPORTANT!!]
I discovered a bug which causes the menus to stop responding to any input. This bug is triggered by using the mouse to select(click) a menu option. To avoid this you should instead use WASD/arrow keys for navigation and the 'enter' key to select an option.

[Note]
You can now press the escape key to bypass the bug that previously prevented you from testing my project.